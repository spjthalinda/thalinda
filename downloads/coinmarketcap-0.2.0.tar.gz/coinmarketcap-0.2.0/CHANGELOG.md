0.2.0 / 2017-04-12
------------------
- switch from `blue-tape` to `tape` and `tape-promise`
- rename `global()` to `globalMarket()`


0.1.0 / 2017-04-12
------------------
- use `yarn`
- add `lib/` to git


0.0.1
-----
- initial release
